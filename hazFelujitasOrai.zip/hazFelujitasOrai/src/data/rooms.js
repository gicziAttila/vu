export const rooms = [
    {
      id: 1,
      name: "Nappali",
      options: ["Festés", "Bútorcsere", "Világítás korszerűsítése"]
    },
    {
      id: 2,
      name: "Konyha",
      options: ["Csempecsere", "Konyhaszekrény felújítása", "Főzőlap korszerűsítése"]
    },
    {
      id: 3,
      name: "Fürdőszoba",
      options: ["Csempecsere", "Mosdócsere", "Fürdőkád csere"]
    }
  ];