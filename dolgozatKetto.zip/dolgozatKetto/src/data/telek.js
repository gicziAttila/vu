const telek1 = { szelesseg: 200, hosszusag: 1000, ar: 2};
const telek2 = { szelesseg: 100, hosszusag: 300, ar: 1};

export const telkek = [telek1, telek2];