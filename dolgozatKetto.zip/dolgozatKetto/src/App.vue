<script setup>
import Telek from './components/Telek.vue'
</script>

<template>
  <header>
    <h1>Telek app</h1>
  </header>
  <main>
    <Telek />
  </main>
  <footer>
    <p>&copy; 2023 Telek app</p>
  </footer>
</template>

<style scoped>
</style>
