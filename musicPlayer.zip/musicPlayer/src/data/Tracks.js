export const t = [
  { title: 'Senki nem', artist: 'Bruno, Vzs, Bákszi apja', file: '../assets/senkiNemSzolRank.mp3' },
  { title: 'PROSECCO', artist: 'KKevin', file: '../assets/kkevin-prosecco.mp3' },
  { title: 'On Sight', artist: 'Kanye West', file: '../assets/onSight-KanyeWest.mp3' }
];